// JavaScript Document

console.log("Linked up");